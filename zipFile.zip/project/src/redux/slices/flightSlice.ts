import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { FlightSearch, Flight, BookedFlight, Airport } from '../../utils/types';
import { supabase } from '../../utils/supabase';

interface DbFlightRow {
  id: string;
  airline: string;
  flight_no: string;
  from_code: string;
  to_code: string;
  departure: string;
  arrival: string;
  duration: string;
  price: number;
  original_price: number;
  seats_left: number;
  class: 'economy' | 'business' | 'first';
  stops: number;
  aircraft: string;
  from_airport: { code: string; city: string; name: string; country: string };
  to_airport: { code: string; city: string; name: string; country: string };
}

interface DbBookingRow {
  id: string;
  flight_id: string;
  passengers: number;
  total_price: number;
  passenger_name: string;
  passenger_email: string;
  passenger_phone: string;
  status: 'confirmed' | 'cancelled';
  booking_ref: string;
  created_at: string;
  flight: DbFlightRow;
}

const mapFlight = (row: DbFlightRow): Flight => ({
  id: row.id,
  airline: row.airline,
  flightNo: row.flight_no,
  from: row.from_airport,
  to: row.to_airport,
  departure: row.departure,
  arrival: row.arrival,
  duration: row.duration,
  price: row.price,
  originalPrice: row.original_price,
  seatsLeft: row.seats_left,
  class: row.class,
  stops: row.stops,
  aircraft: row.aircraft,
});

const mapBooking = (row: DbBookingRow): BookedFlight => ({
  id: row.id,
  flight: mapFlight(row.flight),
  passengers: row.passengers,
  totalPrice: row.total_price,
  bookingDate: row.created_at,
  status: row.status,
  passengerName: row.passenger_name,
  passengerEmail: row.passenger_email,
  passengerPhone: row.passenger_phone,
  bookingRef: row.booking_ref,
});

export const fetchAirports = createAsyncThunk<Airport[]>('flight/fetchAirports', async () => {
  const { data, error } = await supabase.from('airports').select('*').order('city');
  if (error) throw error;
  return (data as Airport[]).map(a => ({ code: a.code, city: a.city, name: a.name, country: a.country }));
});

export const searchFlights = createAsyncThunk<Flight[], FlightSearch>('flight/search', async (search) => {
  const { data, error } = await supabase
    .from('flights')
    .select(`*, from_airport:airports!flights_from_code_fkey(code, city, name, country), to_airport:airports!flights_to_code_fkey(code, city, name, country)`)
    .eq('from_code', search.from)
    .eq('to_code', search.to)
    .eq('class', search.cabinClass);
  if (error) throw error;
  return (data as unknown as DbFlightRow[]).map(mapFlight);
});

export const fetchBookings = createAsyncThunk<BookedFlight[]>('flight/fetchBookings', async () => {
  const { data, error } = await supabase
    .from('bookings')
    .select(`*, flight:flights(*, from_airport:airports!flights_from_code_fkey(code, city, name, country), to_airport:airports!flights_to_code_fkey(code, city, name, country))`)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data as unknown as DbBookingRow[]).map(mapBooking);
});

export const createBooking = createAsyncThunk<BookedFlight, {
  flight: Flight; passengers: number; passengerName: string; passengerEmail: string; passengerPhone: string;
}>('flight/createBooking', async ({ flight, passengers, passengerName, passengerEmail, passengerPhone }) => {
  const bookingRef = 'BK-' + Date.now().toString().slice(-6);
  const totalPrice = flight.price * passengers;
  const { data, error } = await supabase
    .from('bookings')
    .insert({ flight_id: flight.id, passengers, total_price: totalPrice, passenger_name: passengerName, passenger_email: passengerEmail, passenger_phone: passengerPhone, booking_ref: bookingRef })
    .select(`*, flight:flights(*, from_airport:airports!flights_from_code_fkey(code, city, name, country), to_airport:airports!flights_to_code_fkey(code, city, name, country))`)
    .maybeSingle();
  if (error) throw error;
  return mapBooking(data as unknown as DbBookingRow);
});

export const cancelBooking = createAsyncThunk<string, string>('flight/cancelBooking', async (bookingId) => {
  const { error } = await supabase.from('bookings').update({ status: 'cancelled' }).eq('id', bookingId);
  if (error) throw error;
  return bookingId;
});

interface FlightState {
  search: FlightSearch;
  airports: Airport[];
  results: Flight[];
  bookedFlights: BookedFlight[];
  isSearching: boolean;
  isLoadingBookings: boolean;
}

const initialState: FlightState = {
  search: { from: '', to: '', departDate: '', returnDate: '', passengers: 1, tripType: 'roundTrip', cabinClass: 'economy' },
  airports: [],
  results: [],
  bookedFlights: [],
  isSearching: false,
  isLoadingBookings: false,
};

const flightSlice = createSlice({
  name: 'flight',
  initialState,
  reducers: {
    setSearch(state, action: PayloadAction<Partial<FlightSearch>>) {
      state.search = { ...state.search, ...action.payload };
    },
  },
  extraReducers: builder => {
    builder
      .addCase(fetchAirports.fulfilled, (state, action) => { state.airports = action.payload; })
      .addCase(searchFlights.pending, state => { state.isSearching = true; })
      .addCase(searchFlights.fulfilled, (state, action) => { state.results = action.payload; state.isSearching = false; })
      .addCase(searchFlights.rejected, state => { state.isSearching = false; })
      .addCase(fetchBookings.pending, state => { state.isLoadingBookings = true; })
      .addCase(fetchBookings.fulfilled, (state, action) => { state.bookedFlights = action.payload; state.isLoadingBookings = false; })
      .addCase(fetchBookings.rejected, state => { state.isLoadingBookings = false; })
      .addCase(createBooking.fulfilled, (state, action) => { state.bookedFlights.unshift(action.payload); })
      .addCase(cancelBooking.fulfilled, (state, action) => {
        const b = state.bookedFlights.find(b => b.id === action.payload);
        if (b) b.status = 'cancelled';
      });
  },
});

export const { setSearch } = flightSlice.actions;
export default flightSlice.reducer;
